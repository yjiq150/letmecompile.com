//
//  NSManagedObjectContext+OnelineFetch.h
//  SyncPress
//
//  Created by YoungJae Kwon on 13. 8. 15..
//  Copyright (c) 2013년 SunnysideSoft. All rights reserved.
//

#import <CoreData/CoreData.h>

@interface NSManagedObjectContext (OnelineFetch)

- (NSSet *)fetchObjectsForEntityName:(NSString *)newEntityName withPredicate:(id)stringOrPredicate, ...;

@end
