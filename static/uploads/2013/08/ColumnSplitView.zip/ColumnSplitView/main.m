//
//  main.m
//  ColumnSplitView
//
//  Created by Matt Gallagher on 2009/09/01.
//  Copyright Matt Gallagher 2009. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc,  (const char **) argv);
}
